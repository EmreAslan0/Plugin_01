from pytest_allure_db.db_handler import get_db_connection

conn = get_db_connection()
cursor = conn.cursor()

cursor.execute("SELECT * FROM test_results")
results = cursor.fetchall()

for row in results:
    print(row)

conn.close()
